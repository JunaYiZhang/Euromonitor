class addClass {
    addItem() {
        cy.origin('www.saucedemo.com', () => {
            cy.get('[data-test="add-to-cart-sauce-labs-backpack"]').click()
            cy.get('#item_4_title_link > .inventory_item_name')
                .invoke('text')
                .then((name1) => {
                    cy.get('.shopping_cart_link').click()
                    cy.get('.inventory_item_name').should('have.text', name1)
                })
        })
    }
}
export default addClass