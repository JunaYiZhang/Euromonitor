class LoginClass {
    enterNamePwd(username, pwd) {
        cy.origin('www.saucedemo.com', { args: { username, pwd } }, ({ username, pwd }) => {
            cy.visit('https://www.saucedemo.com/');
            cy.get('[data-test="username"]').type(username);
            cy.get('[data-test="password"]').type(pwd);
            cy.get('[data-test="login-button"]').click();
            cy.url().should('be.equal', 'https://www.saucedemo.com/inventory.html')
        })
    }
}
export default LoginClass