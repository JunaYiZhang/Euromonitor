class removeClass {
    removeItem() {
        cy.origin('www.saucedemo.com', () => {
            cy.get('[data-test="remove-sauce-labs-backpack"]').click()
            cy.get('[class^=removed_cart_item]').should('be.empty')
        })
    }
}
export default removeClass