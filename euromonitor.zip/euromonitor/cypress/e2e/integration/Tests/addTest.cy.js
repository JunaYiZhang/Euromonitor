import LoginClass from "../../../e2e/integration/pageObject/login.page_24";
import addClass from "../../../e2e/integration/pageObject/inventory.page";
const login = new LoginClass();
const add = new addClass();

it('addToCart', function () {
    login.enterNamePwd('standard_user', 'secret_sauce');
    add.addItem();
})




