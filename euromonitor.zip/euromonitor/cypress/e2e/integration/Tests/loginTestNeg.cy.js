import LoginClass from "../../../e2e/integration/pageObject/login.page_24";
const login = new LoginClass();

it('login with username,pwd', function () {
    login.enterNamePwd('wrong1', 'wrong2');
})




