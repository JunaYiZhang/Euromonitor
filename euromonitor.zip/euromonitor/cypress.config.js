const { defineConfig } = require("cypress");

module.exports = defineConfig({
  projectId: 'yuwksb',
  e2e: {
    watchForFileChanges: false,
    experimentalSessionAndOrigin: true,
    setupNodeEvents(on, config) {
      // implement node event listeners here
    },
    reporter: 'mochawesome',
    reporterOptions: {
      reportDir: 'cypress/results',
      overwrite: false,
      html: false,
      json: true,
      mochaFile: 'cypress/results/together[hash].xml'

    },
  },
});
